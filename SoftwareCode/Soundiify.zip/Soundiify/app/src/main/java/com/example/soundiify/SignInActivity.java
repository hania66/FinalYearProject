package com.example.soundiify;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.ProgressDialog;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignInActivity extends AppCompatActivity {

    //variables
    private EditText email;
    private EditText  password;
    private Button SignIn;
    private TextView signUpUser;

    private FirebaseAuth auth;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        //registering variables
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        SignIn = findViewById(R.id.SignIn);
        signUpUser = findViewById(R.id.signUpUser);
        pd = new ProgressDialog(this);


        auth = FirebaseAuth.getInstance();



        //The text(Don't have an account?Click here to SignUp) which is written at the xml or designed SignInActivity Page under SignIn Button is for the function of going to SignUpActivity Page,
        // if user don't have an account but by mistake he came on SignInActivity Page,so he will simply click on the text(click here to SignIn) which will lead to the SignUpActivity Page
        //or user can just  use the back button which is the default back button on every mobile screen for going back to the previous activity

        signUpUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignInActivity.this, SignUpActivity.class));
                finish();
            }
        });


        //SignIn button Function which is on the SignInActivityPage,it will only work after taking the input from user about his/her email and  password which they used for registration.
        //So after inputting, user will just click on the button to SignIn.

        SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txt_email = email.getText().toString();
                String txt_password = password.getText().toString();

                //if user will click on the SignIn Button without inputting the email or  password or both ,so it will give popup error message that email and password is required.
                if (TextUtils.isEmpty(txt_email) || TextUtils.isEmpty(txt_password)) {
                    Toast.makeText(SignInActivity.this, "Email and password is required!", Toast.LENGTH_SHORT).show();
                    //else it will take the input of password and email which user will put to signIn
                } else {
                    SignInUser(txt_email, txt_password);
                }
            }

            private void SignInUser(String email, String password) {
                //this is for showing the loading message with progress bar which will work after clicking on SignIn Button,So user can know the Signing In process is going on
                pd.setMessage("please wait");
                pd.show();

                //To signIn the user with email and password which will also be used to check that is it in the record of firebase or not
                auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        //if the SignIn button clicking function worked successfully with the correct information given by the user for signing In,so it will give the message "successfully signed In"
                        // and will lead to the ExistingUserHome page of the application where user will not see the any Choose Music Preference form
                        if (task.isSuccessful()) {
                            Toast.makeText(SignInActivity.this, "Successfully Signed In", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(SignInActivity.this, ExistingUserHome.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            finish();
                        }

                    }

//if any wrong information is given by the user so it will be failed to SignIn  and will show the error message
// For example the account is not  registered ,password is wrong  or email is written in bad format etc.
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pd.dismiss();
                        Toast.makeText(SignInActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });
            }
        });
    }
}