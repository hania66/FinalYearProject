package com.example.soundiify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);



    }
    //after clicking on home icon from setting page,it will lead to previous home activity or user can use default back button
    public void Home(View view){
        onBackPressed();


    }

    //if user wants to go on search from setting page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }



    //In setting Page there is option of choose preference in the form text,after clicking on that it will lead to the choose music preference
    public void ChoosePreference(View view){
        startActivity(new Intent(getApplicationContext(), NewUserHome.class));

    }

    //if user wants to logout from Setting page so he can click on the option of  text logout which is in the form of text
    // after logging out ,it will lead to the SignInPage
    public void logout(View view){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),SignInActivity.class));
        finish();

    }




}