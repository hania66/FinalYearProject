package com.example.soundiify;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class  beemp3 extends AppCompatActivity {
    //variable
    WebView BeeMP3View;

    //method for going back to your app from another interface of app
    @Override
    public void onBackPressed() {
        if (BeeMP3View.canGoBack()) {
            BeeMP3View.goBack();
        } else {


            super.onBackPressed();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beemp3);

        //registering variables
        BeeMP3View=findViewById(R.id.BeeMP3View);
        BeeMP3View.setWebViewClient(new WebViewClient());
        //loading the link of beemp3 online tool
        BeeMP3View.loadUrl("https://beemp3s.net/en8.html");

        //Enabling the javascript settings for showing the interface of beemp3 in your app
        //It's must be set on true otherwise it will not show any interface of that online application which you want to show.
        WebSettings webSettings = BeeMP3View.getSettings();
        webSettings.setJavaScriptEnabled(true);
    }


}