package com.example.soundiify;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import android.app.ProgressDialog;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;



public class SignUpActivity extends AppCompatActivity {

//variables
    private EditText  email;
    private EditText  password;
    private Button    SignUp;
    private TextView signInUser;
    private FirebaseAuth auth;

    ProgressDialog pd;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

//registering variables
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        SignUp = findViewById(R.id.SignUp);
        signInUser = findViewById(R.id.signInUser);
        pd = new ProgressDialog(this);


        auth = FirebaseAuth.getInstance();


       //The text(Already registered?Click here to SignIn) which is written at the xml or designed SignUpActivity Page under SignUp Button is for the function of going to SignInActivity Page,
        // if user has already registered his/her account but by mistake he came on SignUpActivity Page,so he will simply click on the text(click here to SignUp) which will lead to the SignInActivity Page
        //or user can just  use the back button which is the default back button on every mobile screen for going back to the previous activity

        signInUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUpActivity.this , SignInActivity.class));
                finish();
            }
        });



      //SignUp button Function which is on the SignUpActivityPage,it will only work after taking the input from user about his/her email and set password which they want to use for registration.
        //So after , user will just click on the button to register or signup.

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String txt_email = email.getText().toString();
                String txt_password = password.getText().toString();


//if user will click on the SignUp Button without inputting the email or set password or both ,so it will give popup error message that email and password is required.
                if( TextUtils.isEmpty(txt_email) || TextUtils.isEmpty(txt_password)){
                    Toast.makeText(SignUpActivity.this, "Email and password is required!", Toast.LENGTH_SHORT).show();
 // if user set password less than 6 characters so it will give error message that password is too short
                }else if(txt_password.length() < 6){
                    Toast.makeText(SignUpActivity.this, "Password is too shoot", Toast.LENGTH_SHORT).show();
                    //else it will take the input of password and email which user will put to signUp
                }else{
                    SignUpUser(txt_email, txt_password);
                }
            }

        });
    }

    private void SignUpUser(String email, String password) {
        //this is for showing the loading message with progress bar which will work after clicking on SignUp Button,So user can know the Signing Up process is going on
        pd.setMessage("Please Wait!");
        pd.show();

        //for creating the user account with email and password which will also be stored on the firebase.
        // The variable auth is used for the storing on Firebase as you can see above on the top that I used  and registered auth variable with FirebaseAuth.getInstance(); which the function of storing email and password on firebase.
        auth.createUserWithEmailAndPassword(email , password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                //if the SignUp button clicking function worked successfully with the correct registration information given by the user,so it will give the message "successfully signed up"
                // and will lead to the NewUserHome page of the application where user will see the  Choose Music Preference form with checklist before proceeding to the next activity
                if(task.isSuccessful()){
                    Toast.makeText(SignUpActivity.this, "Successfully Signed Up", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SignUpActivity.this , NewUserHome.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();

            }
        };


//if any wrong information is given by the user so it will be failed to SignUp user account and will show the error message
// For example the account is already registered but still using that registered email for registration or email is written in bad format
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss();
                Toast.makeText(SignUpActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }


}