package com.example.soundiify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class HindiMoodActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hindi_mood);
    }

    //if user wants to go on setting from HindiMoodActivity  Page so he can click on the setting icon which is available at the bottom on the screen
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


    }

    //if user wants to go on search from HindiMoodActivity page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }


    //after clicking on the SadBox it will show the HindiSadSongsPlay Page where user  can see the list of hindi sad songs and can play from the list
    public void SadHindiSongs(View view){
        startActivity(new Intent(getApplicationContext(), HindiSadSongsPlay.class));


    }


    //after clicking on the RomanticBox it will show the HindiRomanticSongsPlayActivity Page where user can see the list of hindi romantic songs and can play from the list
    public void RomanticHindiSongs(View view){
        startActivity(new Intent(getApplicationContext(), HindiRomanticSongsPlayActivity.class));


    }


    //after clicking on the FunBox it will show the HindiFunSongsPlay Page where user  can see the list of hindi fun songs and can play from the list
    public void FunHindiSongs(View view){
        startActivity(new Intent(getApplicationContext(), HindiFunSongsPlay.class));


    }

    //if user wants to logout from HindiMoodActivity  page so he can click on the text(logout) which is available on the top right under profile icon.
    // after logging out ,it will lead to the SignInActivityPage
    public void logout(View view){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),SignInActivity.class));
        finish();

    }
}