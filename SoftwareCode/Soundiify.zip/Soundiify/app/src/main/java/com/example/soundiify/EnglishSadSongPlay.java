package com.example.soundiify;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EnglishSadSongPlay extends AppCompatActivity {
    // variables
    private ListView ListView;
    private ImageView imagePlayPause,EnglishSadDownload;
    private TextView CurrentTime,TotalDuration,CurrentSongName;
    private SeekBar seekBar;
    private MediaPlayer mediaPlayer;
    private String currentUrlFromStream;
    private int pauseAtLength;
    private Handler handler = new Handler();
    private DownloadManager download;



    //registering variables
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english_sad_song_play);

        imagePlayPause=findViewById(R.id.imagePlayPause);
        EnglishSadDownload=findViewById(R.id.EnglishSadDownload);
        CurrentTime=findViewById(R.id.CurrentTime);
        TotalDuration=findViewById(R.id.TotalDuration);
        seekBar=findViewById(R.id.seekBar);
        CurrentSongName=findViewById(R.id.CurrentSongName);
        ListView =findViewById(R.id.ListView);
        mediaPlayer = new MediaPlayer();



        //It will download all the English Sad Songs Playlist when user will click on the downloading icon which is available on the top of the play list
        EnglishSadDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // For Loop for downloading all playlist
                for (int i = 0; i < 1; i++){
                    download = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri uriEnglishSad1 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Passenger%20%20%20Let%20Her%20Go%20%20%20.mp3?alt=media&token=25eb85b8-c343-4fa3-93fc-60b927cd8779");
                    DownloadManager.Request EnglishSad1request = new DownloadManager.Request(uriEnglishSad1);
                    EnglishSad1request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishSad1request.setTitle("Passenger Let Her Go" + i + ".mp3");
                    EnglishSad1request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Passenger Let Her Go/"  + "/" + "Passenger Let Her Go" + i + ".mp3");
                    Long EnglishRomantic1reference = download.enqueue(EnglishSad1request);



                    //
                    Uri uriEnglishSad2 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/SLANDER%20-%20I'm%20sorry%20don't%20leave%20me%20%20Love%20Is%20Gone%20%20%20Lyrics%20%20ft%20%20Dylan%20Matthew%20%20Acoustic%20.mp3?alt=media&token=312f3187-6335-4dc6-bea2-7421fae49ce9");
                    DownloadManager.Request EnglishSad2request = new DownloadManager.Request(uriEnglishSad2);
                    EnglishSad2request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishSad2request.setTitle( "SLANDER - I'm sorry don't leave me Love" + i + ".mp3");
                    EnglishSad2request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/SLANDER - I'm sorry don't leave me Love/"  + "/" + "SLANDER - I'm sorry don't leave me Love" + i + ".mp3");
                    Long EnglishSad2reference = download.enqueue(EnglishSad2request);


                    Uri uriEnglishSad3 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Arash%20-%20Broken%20Angel.mp3?alt=media&token=facea97a-1670-447e-aea2-2d448cadb442");
                    DownloadManager.Request EnglishSad3request = new DownloadManager.Request(uriEnglishSad3);
                    EnglishSad3request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishSad3request.setTitle( " Arash - Broken Angel" + i + ".mp3");
                    EnglishSad3request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Arash - Broken Angel/"  + "/" + "Arash - Broken Angel" + i + ".mp3");
                    Long EnglishSad3reference = download.enqueue(EnglishSad3request);


                    Uri uriEnglishSad4 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Apologize%20-%20OneRepublic.mp3?alt=media&token=bea8cfac-a953-432c-89fe-c1be6df6a731");
                    DownloadManager.Request EnglishSad4request = new DownloadManager.Request(uriEnglishSad4);
                    EnglishSad4request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishSad4request.setTitle( "Apologize - OneRepublic" + i + ".mp3");
                    EnglishSad4request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Apologize - OneRepublic/"  + "/" + "Apologize - OneRepublic" + i + ".mp3");
                    Long EnglishRomantic4reference = download.enqueue(EnglishSad4request);


                    Uri uriEnglishSad5 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Alan%20Walker%20%26%20Ava%20Max%20-%20Alone%20%20Pt%20%20II%20_%20cover%20by%20COLOR%20MUSIC%20Choir.mp3?alt=media&token=a681e7aa-0d73-46f5-80f0-c930e0202fbe");
                    DownloadManager.Request EnglishSad5request = new DownloadManager.Request(uriEnglishSad5);
                    EnglishSad5request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishSad5request.setTitle( "Alan Walker & Ava Max - Alone  " + i + ".mp3");
                    EnglishSad5request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Alan Walker & Ava Max - Alone  /"  + "/" + "Alan Walker & Ava Max - Alone  " + i + ".mp3");
                    Long EnglishSad5reference = download.enqueue(EnglishSad5request);




                }
            }
        });
        seekBar.setMax(100);


        //function of play and pause,which will work on clicking
        imagePlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if user wants to pause  so after pausing it will show the play icon to play again.
                if(mediaPlayer.isPlaying()){
                    handler.removeCallbacks(updater);
                    mediaPlayer.pause();
                    imagePlayPause.setImageResource(R.drawable.playicon);
                    //else user wants to play so after playing  it will show the pause icon to pause again and will update the seekbar according to the progress of song.
                }else {
                    mediaPlayer.start();
                    imagePlayPause.setImageResource(R.drawable.pause);
                    updateSeekBar();
                }
            }
        });


        //for displaying the songs list on the screen
        displaySong();
    }

    //displaySong method
    public void displaySong(){
        //EnglishSadSongsList variable is used for putting url of all EnglishFunSongs songs which is from online streaming.
        final List<String> EnglishSadSongsList= new ArrayList<>();
        EnglishSadSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Passenger%20%20%20Let%20Her%20Go%20%20%20.mp3?alt=media&token=25eb85b8-c343-4fa3-93fc-60b927cd8779");
        EnglishSadSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/SLANDER%20-%20I'm%20sorry%20don't%20leave%20me%20%20Love%20Is%20Gone%20%20%20Lyrics%20%20ft%20%20Dylan%20Matthew%20%20Acoustic%20.mp3?alt=media&token=312f3187-6335-4dc6-bea2-7421fae49ce9");
        EnglishSadSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Arash%20-%20Broken%20Angel.mp3?alt=media&token=facea97a-1670-447e-aea2-2d448cadb442");
        EnglishSadSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Apologize%20-%20OneRepublic.mp3?alt=media&token=2c64b20b-a20b-402e-8a45-660689bbdf88");
        EnglishSadSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Alan%20Walker%20%26%20Ava%20Max%20-%20Alone%20%20Pt%20%20II%20_%20cover%20by%20COLOR%20MUSIC%20Choir.mp3?alt=media&token=a681e7aa-0d73-46f5-80f0-c930e0202fbe");



        //Adapter for English Sad Songs
        ArrayAdapter arrayAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,EnglishSadSongsList){

            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                //Setting the view of text for English Sad Songs List which will be appeared on the screen
                TextView txtSong=(TextView) super.getView(position, convertView, parent);
                txtSong.setTag(EnglishSadSongsList.get(position));
                txtSong.setTextColor(Color.parseColor("#FFFFFFFF"));
                txtSong.setTypeface(txtSong.getTypeface(), Typeface.BOLD);
                txtSong.setText(EnglishSadSongsList.get(position).substring(EnglishSadSongsList.get(position).lastIndexOf("/")+1));
                txtSong.setTextSize(TypedValue.COMPLEX_UNIT_DIP,22);
                return txtSong;

            }
        };

        //all the list of EnglishSadSongs will be appeared in the listView
        ListView listView=(ListView)findViewById(R.id.ListView);
        //method for clicking on any one of list item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                //will show the name of current song playing
                currentUrlFromStream=view.getTag().toString();
                CurrentSongName.setText(currentUrlFromStream.substring(currentUrlFromStream.lastIndexOf("/")+1));

                try{
                    if(mediaPlayer!=null){
                        mediaPlayer.stop();
                    }
                    pauseAtLength=0;
                    mediaPlayer=new MediaPlayer();
                    mediaPlayer.setDataSource(currentUrlFromStream);
                    mediaPlayer.prepareAsync();

                    //When any one of the items song list will be clicked  it will show the current playing songs with pause icon to pause it
                    // also it will show the current and total duration of played song
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            mediaPlayer.start();
                            imagePlayPause.setImageResource(R.drawable.pause);
                            TotalDuration.setText(milliSecondsToTimer(mediaPlayer.getDuration()));
                            updateSeekBar();
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();

                }
            }
        });

        listView.setAdapter(arrayAdapter);




    }

    //function or method for updating the current time of played song
    private Runnable updater = new Runnable() {
        @Override
        public void run() {
            updateSeekBar();
            long currentDuration = mediaPlayer.getCurrentPosition();
            CurrentTime.setText(milliSecondsToTimer(currentDuration));

        }
    };


    //function for updating the seekbar of current played song
    private void updateSeekBar(){
        if(mediaPlayer.isPlaying()){
            seekBar.setProgress((int) (((float) mediaPlayer.getCurrentPosition()/ mediaPlayer.getDuration()) *100));
            handler.postDelayed(updater, 1000);
        }
    }


    //method for detecting the timing of current played song in hours,minutes or seconds
    private String milliSecondsToTimer(long milliSeconds){
        String timerString="";
        String secondsString;

        int hours = (int)(milliSeconds / (1000*60*60));
        int minutes = (int)(milliSeconds % (1000*60*60)) / (1000*60);
        int seconds = (int)(milliSeconds % (1000*60*60)) % (1000*60) / (1000);

        if (hours > 0){
            timerString = hours + ":";

        }
        if(seconds < 10){
            secondsString = "0" + seconds;

        }else{
            secondsString="" + seconds;
        }

        timerString = timerString + minutes + ":" +secondsString;
        return timerString;
    }

    //after clicking on home icon from EnglishSadSongsPlayActivity page,it will lead to previous home activity or user can use default back button
    public void Home(View view){
        onBackPressed();
    }




    //if user wants to go on setting from EnglishSadSongsPlayActivity Page so he can click on the setting icon which is available at the bottom on the screen
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


    }


    //if user wants to go on search from EnglishSadSongsPlayActivity  Page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }


}