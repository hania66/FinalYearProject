package com.example.soundiify;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EnglishFunSongPlay extends AppCompatActivity {

    //variables
    private ListView ListView;
    private ImageView imagePlayPause,EnglishFundownload;
    private TextView CurrentTime,TotalDuration,CurrentSongName;
    private SeekBar seekBar;
    private MediaPlayer mediaPlayer;
    private String currentUrlFromStream;
    private int pauseAtLength;
    private Handler handler = new Handler();
    private DownloadManager download;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english_fun_song_play);


        //registering variables

        imagePlayPause=findViewById(R.id.imagePlayPause);
        EnglishFundownload=findViewById(R.id.EnglishFundownload);
        CurrentTime=findViewById(R.id.CurrentTime);
        TotalDuration=findViewById(R.id.TotalDuration);
        seekBar=findViewById(R.id.seekBar);
        CurrentSongName=findViewById(R.id.CurrentSongName);
        ListView =findViewById(R.id.ListView);
        mediaPlayer = new MediaPlayer();



        //It will download all the English Fun Songs Playlist when user will click on the downloading icon which is available on the top of the play list
        EnglishFundownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // For Loop for downloading all playlist
                for (int i = 0; i < 1; i++) {
                    download = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri uriEnglishFun1 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Hollywood%20Swinging.mp3?alt=media&token=312f758b-f579-4821-89e1-852fe269930f");
                    DownloadManager.Request EnglishFun1request = new DownloadManager.Request(uriEnglishFun1);
                    EnglishFun1request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishFun1request.setTitle("Swinging" + i + ".mp3");
                    EnglishFun1request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Swinging/"  + "/" + "Swinging" + i + ".mp3");
                    Long EnglishFun1reference = download.enqueue(EnglishFun1request);




                    Uri uriEnglishFun2 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Major%20Lazer%20%26%20DJ%20Snake%20-%20Lean%20On%20%20feat%20%20M%C3%98%20%20%20%20.mp3?alt=media&token=c7b13ea8-ff74-44ff-95a1-63833f76a542");
                    DownloadManager.Request EnglishFun2request = new DownloadManager.Request(uriEnglishFun2);
                    EnglishFun2request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishFun2request.setTitle("Major Lazer & DJ -Snake Lean on Feat" + i + ".mp3");
                    EnglishFun2request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Major Lazer & DJ -Snake Lean on Feat/"  + "/" + "Major Lazer & DJ -Snake Lean on Feat" + i + ".mp3");
                    Long EnglishFun2reference = download.enqueue(EnglishFun2request);


                    Uri uriEnglishFun3 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Marshmello%20%26%20Anne-Marie%20-%20FRIENDS%20%20Music%20Video%20%20%20OFFICIAL%20FRIENDZONE%20ANTHEM%20.mp3?alt=media&token=193b0cdb-61b1-4561-85b0-6c52e1843f26");
                    DownloadManager.Request EnglishFun3request = new DownloadManager.Request(uriEnglishFun3);
                    EnglishFun3request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishFun3request.setTitle( "Marshmello & Anne" + i + ".mp3");
                    EnglishFun3request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Marshmello & Anne/"  + "/" + "Marshmello & Anne" + i + ".mp3");
                    Long EnglishFun3reference = download.enqueue(EnglishFun3request);


                    Uri uriEnglishFun4 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Marshmello%20%26%20Anne-Marie%20-%20FRIENDS%20%20Music%20Video%20%20%20OFFICIAL%20FRIENDZONE%20ANTHEM%20.mp3?alt=media&token=193b0cdb-61b1-4561-85b0-6c52e1843f26");
                    DownloadManager.Request EnglishFun4request = new DownloadManager.Request(uriEnglishFun4);
                    EnglishFun4request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishFun4request.setTitle( "Marshmello" + i + ".mp3");
                    EnglishFun4request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Marshmello/"  + "/" + "Marshmello" + i + ".mp3");
                    Long EnglishFun4reference = download.enqueue(EnglishFun4request);


                    Uri uriEnglishFun5 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Ed%20Sheeran%20-%20Shape%20of%20You%20%20Lyrics%20.mp3?alt=media&token=133a9173-646f-4539-9eaf-d5b742e34864");
                    DownloadManager.Request EnglishFun5request = new DownloadManager.Request(uriEnglishFun5);
                    EnglishFun5request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishFun5request.setTitle("Shape of You" + i + ".mp3");
                    EnglishFun5request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Shape of You/"  + "/" + "Shae of You" + i + ".mp3");
                    Long EnglishFun5reference = download.enqueue(EnglishFun5request);




                }
            }
        });


        seekBar.setMax(100);






        //function of play and pause,which will work on clicking
        imagePlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //if user wants to pause ,so after pausing it will show the play icon to play again.
                if(mediaPlayer.isPlaying()){
                    handler.removeCallbacks(updater);
                    mediaPlayer.pause();
                    imagePlayPause.setImageResource(R.drawable.playicon);
                    //else user wants to play so after playing it will show the pause icon to pause again and will update the seekbar according to the progress of song.
                }else {
                    mediaPlayer.start();
                    imagePlayPause.setImageResource(R.drawable.pause);
                    updateSeekBar();
                }
            }
        });



        //for displaying the songs list on the screen
        displaySong();
    }

    //displaySong method
    public void displaySong(){
        //EnglishFunSongsList variable is used for putting url of all EnglishFunSongs songs which is from online streaming.
        final List<String> EnglishFunSongsList= new ArrayList<>();
        EnglishFunSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Hollywood%20Swinging.mp3?alt=media&token=312f758b-f579-4821-89e1-852fe269930f");
        EnglishFunSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Major%20Lazer%20%26%20DJ%20Snake%20-%20Lean%20On%20%20feat%20%20M%C3%98%20%20%20%20.mp3?alt=media&token=c7b13ea8-ff74-44ff-95a1-63833f76a542");
        EnglishFunSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Marshmello%20%26%20Anne-Marie%20-%20FRIENDS%20%20Music%20Video%20%20%20OFFICIAL%20FRIENDZONE%20ANTHEM%20.mp3?alt=media&token=35348f61-e851-4d4e-bfa2-409065806e69");
        EnglishFunSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Hollywood%20Swinging.mp3?alt=media&token=312f758b-f579-4821-89e1-852fe269930f");
        EnglishFunSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Ed%20Sheeran%20-%20Shape%20of%20You%20%20Lyrics%20.mp3?alt=media&token=133a9173-646f-4539-9eaf-d5b742e34864");

        //Adapter for English Fun Songs
        ArrayAdapter arrayAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,EnglishFunSongsList){

            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                //Setting the view of text for English Fun Songs List which will be appeared on the screen
                TextView txtSong=(TextView) super.getView(position, convertView, parent);
                txtSong.setTag(EnglishFunSongsList.get(position));
                txtSong.setTextColor(Color.parseColor("#FFFFFFFF"));
                txtSong.setTypeface(txtSong.getTypeface(), Typeface.BOLD);
                txtSong.setText(EnglishFunSongsList.get(position).substring(EnglishFunSongsList.get(position).lastIndexOf("/")+1));
                txtSong.setTextSize(TypedValue.COMPLEX_UNIT_DIP,22);

                return txtSong;

            }
        };

        //all the list of EnglishFunSongs will be appeared in the listView
        ListView listView=(ListView)findViewById(R.id.ListView);
        //method for clicking on any one of list item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                //will show the name of current song playing
                currentUrlFromStream=view.getTag().toString();
                CurrentSongName.setText(currentUrlFromStream.substring(currentUrlFromStream.lastIndexOf("/")+1));

                try{
                    if(mediaPlayer!=null){
                        mediaPlayer.stop();
                    }
                    pauseAtLength=0;
                    mediaPlayer=new MediaPlayer();
                    mediaPlayer.setDataSource(currentUrlFromStream);
                    mediaPlayer.prepareAsync();

                    //When any one of the items song list will be clicked  it will show the current playing songs with pause icon to pause it
                    // also it will show the current and total duration of played song
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            mediaPlayer.start();
                            imagePlayPause.setImageResource(R.drawable.pause);
                            TotalDuration.setText(milliSecondsToTimer(mediaPlayer.getDuration()));
                            updateSeekBar();
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();

                }
            }
        });

        listView.setAdapter(arrayAdapter);




    }

    //function or method for updating the current time of played song
    private Runnable updater = new Runnable() {
        @Override
        public void run() {
            updateSeekBar();
            long currentDuration = mediaPlayer.getCurrentPosition();
            CurrentTime.setText(milliSecondsToTimer(currentDuration));

        }
    };

    //function for updating the seekbar of current played song
    private void updateSeekBar(){
        if(mediaPlayer.isPlaying()){
            seekBar.setProgress((int) (((float) mediaPlayer.getCurrentPosition()/ mediaPlayer.getDuration()) *100));
            handler.postDelayed(updater, 1000);
        }
    }


    //method for detecting the timing of current played song in hours,minutes or seconds
    private String milliSecondsToTimer(long milliSeconds){
        String timerString="";
        String secondsString;

        int hours = (int)(milliSeconds / (1000*60*60));
        int minutes = (int)(milliSeconds % (1000*60*60)) / (1000*60);
        int seconds = (int)(milliSeconds % (1000*60*60)) % (1000*60) / (1000);

        if (hours > 0){
            timerString = hours + ":";

        }
        if(seconds < 10){
            secondsString = "0" + seconds;

        }else{
            secondsString="" + seconds;
        }

        timerString = timerString + minutes + ":" +secondsString;
        return timerString;
    }

    //after clicking on home icon from EnglishFunSongsPlayActivity page,it will lead to previous home activity or user can use default back button
    public void Home(View view){
        onBackPressed();
    }

    //if user wants to go on settings from EnglishFunSongsPlayActivity  Page so he can click on the search icon which is available at the bottom on the screen
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


    }

    //if user wants to go on search from EnglishFunSongsPlayActivity  Page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }




}