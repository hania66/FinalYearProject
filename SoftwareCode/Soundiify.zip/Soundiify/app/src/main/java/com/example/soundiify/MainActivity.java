package com.example.soundiify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {
    // private variables
    private Button SignUp;
    private Button SignIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//registering variables
        SignUp = findViewById(R.id.SignUp);
        SignIn = findViewById(R.id.SignIn);


        //the SignUp button  function which is on the main page,when user will click on this it will lead to the SignUpActivity Page

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this , SignUpActivity.class));

            }
        });

        //the SignIn button  function which is on the main page,when user will click on this it will lead to the SignInActivity Page
        SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this , SignInActivity.class));

            }
        });
    }
}