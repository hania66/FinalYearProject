package com.example.soundiify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class  SearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    }
    //after clicking on home icon from search page,it will lead to previous home activity or user can use default back button
    public void Home(View view){
        onBackPressed();

    }
    //if user wants to go on setting from search  Page so he can click on the setting icon which is available at the bottom on the screen
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


//When user will click on BEEMP3 button which is located on search page,it will show the interface of another online app
        //which willl be able to search any type of songs
    }
    public void OpenBEEMP3View(View view){
        startActivity(new Intent(getApplicationContext(),beemp3.class));

    }


    //if user wants to logout from Search page so he can click on the text(logout) which is available on the top right under profile icon.
    // after logging out ,it will lead to the SignInActivityPage
    public void logout(View view){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),SignInActivity.class));
        finish();

    }
}