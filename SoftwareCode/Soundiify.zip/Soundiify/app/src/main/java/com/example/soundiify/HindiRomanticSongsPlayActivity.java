package com.example.soundiify;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HindiRomanticSongsPlayActivity extends AppCompatActivity {
//variables
    private ListView ListView;

    private ImageView imagePlayPause,RomanticHindiDownload;
    private TextView CurrentTime,TotalDuration,CurrentSongName;
    private SeekBar seekBar;
    private MediaPlayer mediaPlayer;
    private String currentUrlFromStream;
    private int pauseAtLength;
    private Handler handler = new Handler();
    private DownloadManager download;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hindi_romantic_songs_play);
//registering variables
        imagePlayPause=findViewById(R.id.imagePlayPause);
        RomanticHindiDownload=findViewById(R.id.RomanticHindiDownload);
        CurrentTime=findViewById(R.id.CurrentTime);
        TotalDuration=findViewById(R.id.TotalDuration);
        seekBar=findViewById(R.id.seekBar);
        CurrentSongName=findViewById(R.id.CurrentSongName);
        ListView =findViewById(R.id.ListView);
        mediaPlayer = new MediaPlayer();


        //It will download all the Hindi Romantic Songs Playlist when user will click on the downloading icon which is available on the top of the play list
        RomanticHindiDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //For Loop for downloading playlist
                for (int i = 0; i < 1; i++){
                    download = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri uriHindiRomantic1 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Baarish%20-%20Full%20Video%20%20%20Half%20Girlfriend%20%20%20Arjun%20Kapoor%20%26%20Shraddha%20Kapoor%20%20Ash%20King%20%20%20Sashaa%20%20%20Tanishk.mp3?alt=media&token=86a705d1-badb-40cd-a3a6-8e4e4397235f");
                    DownloadManager.Request HindiRomantic1request = new DownloadManager.Request(uriHindiRomantic1);
                    HindiRomantic1request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    HindiRomantic1request.setTitle( "Baarish  " + i + ".mp3");
                    HindiRomantic1request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Baarish  /"  + "/" + "Baarish " + i + ".mp3");
                    Long HindiRomantic1reference = download.enqueue(HindiRomantic1request);



                    //
                    Uri uriHindiRomantic2 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Jisko%20duao%20me%20manga%20%20%20Jisko%20duaon%20mein%20manga%20full%20song%20%20%20HD.mp3?alt=media&token=28e614c8-69d2-48c8-8141-7a6aacdf01bb");
                    DownloadManager.Request HindiRomantic2request = new DownloadManager.Request(uriHindiRomantic2);
                    HindiRomantic2request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    HindiRomantic2request.setTitle( "Jisko duao me manga" + i + ".mp3");
                    HindiRomantic2request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Jisko duao me manga/"  + "/" + "Jisko duao me manga" + i + ".mp3");
                    Long HindiRomantic2reference = download.enqueue(HindiRomantic2request);


                    Uri uriHindiRomantic3 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Raataan%20Lambiyan%20-%20Lyric%20Video%20Shershaah%20Sidharth%20%E2%80%93%20Kiara%20Tanishk%20B%20%20Jubin%20Asees.mp3?alt=media&token=38c6b172-5ce6-4325-b96c-b62ec2ac112c");
                    DownloadManager.Request HindiRomantic3request = new DownloadManager.Request(uriHindiRomantic3);
                    HindiRomantic3request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    HindiRomantic3request.setTitle(" Raataan Lambiyan" + i + ".mp3");
                    HindiRomantic3request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Raataan Lambiyan/"  + "/" + "Raataan Lambiyan" + i + ".mp3");
                    Long HindiRomanticreference = download.enqueue(HindiRomantic3request);


                    Uri uriHindiRomantic4 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Dil%20Ko%20Karaar%20Aaya%20-%20Sidharth%20Shukla%20%26%20Neha%20Sharma%20%20%20Neha%20Kakkar%20%26%20YasserDesai%20%20%20Rajat%20Nagpal%20%20%20Rana.mp3?alt=media&token=bbd00d3e-ebea-45e8-95ee-4ce041c4a9fb");
                    DownloadManager.Request HindiRomantic4request = new DownloadManager.Request(uriHindiRomantic4);
                    HindiRomantic4request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    HindiRomantic4request.setTitle( "Dil Ko Karaar Aaya" + i + ".mp3");
                    HindiRomantic4request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Dil Ko Karaar Aaya/"  + "/" + "Dil Ko Karaar Aaya" + i + ".mp3");
                    Long HindiRomantic4reference = download.enqueue(HindiRomantic4request);


                    Uri uriHindiRomantic5 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Lyrical%20%20Dil%20Mein%20Ho%20Tum%20%20WHY%20CHEAT%20INDIA%20%20%20Emraan%20H%20%20Shreya%20D%20Rochak%20K%20%20Armaan%20M%20%20Bappi%20L%20%20Manoj%20M.mp3?alt=media&token=da957296-b5f2-4c1c-8ec7-a2ab4f347036");
                    DownloadManager.Request HindiRomantic5request = new DownloadManager.Request(uriHindiRomantic5);
                    HindiRomantic5request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    HindiRomantic5request.setTitle("Dil Mein Ho Tum " + i + ".mp3");
                    HindiRomantic5request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Dil Mein Ho Tum/"  + "/" + "Dil Mein Ho Tum " + i + ".mp3");
                    Long HindiRomantic5reference = download.enqueue(HindiRomantic5request);


                }
            }
        });

        seekBar.setMax(100);


        //function of play and pause,which will work on clicking,

        imagePlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //if user wants to pause so after pausing it  will show the play icon to play again.
                if(mediaPlayer.isPlaying()){
                    handler.removeCallbacks(updater);
                    mediaPlayer.pause();
                    imagePlayPause.setImageResource(R.drawable.playicon);

                    //else user wants to play so  after playing it will show the pause icon to pause again and will update the seekbar according to the progress of song.
                }else {
                    mediaPlayer.start();
                    imagePlayPause.setImageResource(R.drawable.pause);
                    updateSeekBar();
                }
            }
        });


       //for displaying the songs list on the screen
        displaySong();
    }

//displaySong method
    public void displaySong(){
        //HindiRomanticSongsList variable is used for putting url of all hindiRomanticSongs songs which is from online streaming.
        final List<String> HindiRomanticSongsList= new ArrayList<>();
        HindiRomanticSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Baarish%20-%20Full%20Video%20%20%20Half%20Girlfriend%20%20%20Arjun%20Kapoor%20%26%20Shraddha%20Kapoor%20%20Ash%20King%20%20%20Sashaa%20%20%20Tanishk.mp3?alt=media&token=86a705d1-badb-40cd-a3a6-8e4e4397235f");
        HindiRomanticSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Jisko%20duao%20me%20manga%20%20%20Jisko%20duaon%20mein%20manga%20full%20song%20%20%20HD.mp3?alt=media&token=28e614c8-69d2-48c8-8141-7a6aacdf01bb");
        HindiRomanticSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Raataan%20Lambiyan%20-%20Lyric%20Video%20Shershaah%20Sidharth%20%E2%80%93%20Kiara%20Tanishk%20B%20%20Jubin%20Asees.mp3?alt=media&token=38c6b172-5ce6-4325-b96c-b62ec2ac112c");
        HindiRomanticSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Dil%20Ko%20Karaar%20Aaya%20-%20Sidharth%20Shukla%20%26%20Neha%20Sharma%20%20%20Neha%20Kakkar%20%26%20YasserDesai%20%20%20Rajat%20Nagpal%20%20%20Rana.mp3?alt=media&token=bbd00d3e-ebea-45e8-95ee-4ce041c4a9fb");
        HindiRomanticSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Lyrical%20%20Dil%20Mein%20Ho%20Tum%20%20WHY%20CHEAT%20INDIA%20%20%20Emraan%20H%20%20Shreya%20D%20Rochak%20K%20%20Armaan%20M%20%20Bappi%20L%20%20Manoj%20M.mp3?alt=media&token=da957296-b5f2-4c1c-8ec7-a2ab4f347036");

//Adapter for Hindi Romantic Songs
        ArrayAdapter arrayAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,HindiRomanticSongsList){

            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

                //Setting the view of text for Hindi Romantic Songs List which will be appeared on the screen
                TextView txtSong=(TextView) super.getView(position, convertView, parent);
                txtSong.setTag(HindiRomanticSongsList.get(position));
                txtSong.setTextColor(Color.parseColor("#FFFFFFFF"));
                txtSong.setTypeface(txtSong.getTypeface(), Typeface.BOLD);
                txtSong.setText(HindiRomanticSongsList.get(position).substring(HindiRomanticSongsList.get(position).lastIndexOf("/")+1));
                txtSong.setTextSize(TypedValue.COMPLEX_UNIT_DIP,22);
                return txtSong;

            }
        };

//all the list of HindiRomanticSongs will be appeared in the listView
        ListView listView=(ListView)findViewById(R.id.ListView);

        //method for clicking on any one of list item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                //will show the name of current song playing
                currentUrlFromStream=view.getTag().toString();
                CurrentSongName.setText(currentUrlFromStream.substring(currentUrlFromStream.lastIndexOf("/")+1));

                try{

                    if(mediaPlayer!=null){
                        mediaPlayer.stop();
                    }
                    pauseAtLength=0;
                    mediaPlayer=new MediaPlayer();
                    mediaPlayer.setDataSource(currentUrlFromStream);
                    mediaPlayer.prepareAsync();

                   //When any one of the items song list will be clicked  it will show the current playing songs with pause icon to pause it
                    // also it will show the current and total duration of played song.
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            mediaPlayer.start();
                            TotalDuration.setText(milliSecondsToTimer(mediaPlayer.getDuration()));
                            imagePlayPause.setImageResource(R.drawable.pause);
                            updateSeekBar();

                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();

                }

            }
        });

        listView.setAdapter(arrayAdapter);




    }

//function or method for updating the current time of played song
    private Runnable updater = new Runnable() {
        @Override
        public void run() {
            updateSeekBar();
            long currentDuration = mediaPlayer.getCurrentPosition();
            CurrentTime.setText(milliSecondsToTimer(currentDuration));

        }
    };

    //function for updating the seekbar of current played song
    private void updateSeekBar(){
        if(mediaPlayer.isPlaying()){
            seekBar.setProgress((int) (((float) mediaPlayer.getCurrentPosition()/ mediaPlayer.getDuration()) *100));
            handler.postDelayed(updater, 1000);
        }
    }

    //method for detecting the timing of current played song in hours,minutes or seconds
    private String milliSecondsToTimer(long milliSeconds){
        String timerString="";
        String secondsString;

        int hours = (int)(milliSeconds / (1000*60*60));
        int minutes = (int)(milliSeconds % (1000*60*60)) / (1000*60);
        int seconds = (int)(milliSeconds % (1000*60*60)) % (1000*60) / (1000);

        if (hours > 0){
            timerString = hours + ":";

        }
        if(seconds < 10){
            secondsString = "0" + seconds;

        }else{
            secondsString="" + seconds;
        }

        timerString = timerString + minutes + ":" +secondsString;
        return timerString;
    }

    //after clicking on home icon from HindiRomanticSongsPlayActivity page,it will lead to previous home activity or user can use default back button
    public void Home(View view){
        onBackPressed();


    }

    //if user wants to go on setting from HindiRomanticSongsPlayActivity Page so he can click on the setting icon which is available at the bottom on the screen
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


    }
    //if user wants to go on search from HindiRomanticSongsPlayActivity  Page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }



    
}