package com.example.soundiify;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HindiSadSongsPlay extends AppCompatActivity {
//variables
    private ListView ListView;
    private ImageView imagePlayPause,SadHindiDownload;
    private TextView CurrentTime,TotalDuration,CurrentSongName;
    private SeekBar seekBar;
    private MediaPlayer mediaPlayer;
    private String currentUrlFromStream;
    private int pauseAtLength;
    private Handler handler = new Handler();
    private DownloadManager download;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hindi_sad_songs_play);

//registering variable
        imagePlayPause=findViewById(R.id.imagePlayPause);
        SadHindiDownload=findViewById(R.id.SadHindiDownload);
        CurrentTime=findViewById(R.id.CurrentTime);
        TotalDuration=findViewById(R.id.TotalDuration);
        seekBar=findViewById(R.id.seekBar);
        CurrentSongName=findViewById(R.id.CurrentSongName);
        ListView =findViewById(R.id.ListView);
        mediaPlayer = new MediaPlayer();


        //It will download all the Hindi Sad Songs Playlist when user will click on the downloading icon which is available on the top of the play list
        SadHindiDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // For Loop for downloading all playlist
                for (int i = 0; i < 1; i++){
                    download = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri uriHindiSad1 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Filhaal2%20Mohabbat%20%20%20Akshay%20Kumar%20Ft%20Nupur%20Sanon%20%20%20Ammy%20Virk%20%20%20BPraak%20%20%20Jaani%20%20%20Arvindr%20Khaira.mp3?alt=media&token=5dcc5063-14e5-4d99-945a-9c0a2cddd07a");
                    DownloadManager.Request HindiSad1request = new DownloadManager.Request(uriHindiSad1);
                    HindiSad1request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    HindiSad1request.setTitle( "Filhaal2" + i + ".mp3");
                    HindiSad1request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Filhaal2/"  + "/" + "Filhaal2 " + i + ".mp3");
                    Long HindiSad1reference = download.enqueue(HindiSad1request);



                    //
                    Uri uriHindiSad2 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Chhor%20Denge%20Song%20-%20Nora%20Fatehi%20ft%20%20Ehan%20bhatt%20%20%20Parampara%20T%20%20%20Sachet-Tandon%20B%20%20%20Chhor%20Denge%20New%20Song.mp3?alt=media&token=f2f97005-7679-49fd-b3b5-c4b7fad9c846");
                    DownloadManager.Request HindiSad2request = new DownloadManager.Request(uriHindiSad2);
                    HindiSad2request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    HindiSad2request.setTitle( "Chhor Denge Song" + i + ".mp3");
                    HindiSad2request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Chhor Denge Song/"  + "/" + "Chhor Denge Song" + i + ".mp3");
                    Long HindiSad2reference = download.enqueue(HindiSad2request);


                    Uri uriHindiSad3 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Mann%20Bharryaa%202%200%20%20From%20%20Shershaah%20%20.mp3?alt=media&token=c6ac2de3-9f73-4dcb-bbf8-3a4e55efaeb4");
                    DownloadManager.Request HindiSad3request = new DownloadManager.Request(uriHindiSad3);
                    HindiSad3request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    HindiSad3request.setTitle("Mann Bharryaa " + i + ".mp3");
                    HindiSad3request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Mann Bharryaa/"  + "/" + "Mann Bharryaa" + i + ".mp3");
                    Long HindiSadreference = download.enqueue(HindiSad3request);


                    Uri uriHindiSad4 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Lyrical%20%20Tum%20Hi%20Aana%20%20%20Marjaavaan%20%20%20Riteish%20D%20%20Sidharth%20M%20%20Tara%20S%20%20Jubin%20Nautiyal%20Payal%20Dev%20Kunaal%20V.mp3?alt=media&token=25db7b63-9085-4159-9524-a552caaac18c");
                    DownloadManager.Request HindiSad4request = new DownloadManager.Request(uriHindiSad4);
                    HindiSad4request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    HindiSad4request.setTitle( "Tum Hi Aana" + i + ".mp3");
                    HindiSad4request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Tum Hi Aana/"  + "/" + "Tum Hi Aana" + i + ".mp3");
                    Long HindiSad4reference = download.enqueue(HindiSad4request);


                    Uri uriHindiSad5 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Mann%20Bharryaa%202%200%20%20From%20%20Shershaah%20%20.mp3?alt=media&token=c6ac2de3-9f73-4dcb-bbf8-3a4e55efaeb4");
                    DownloadManager.Request HindiSad5request = new DownloadManager.Request(uriHindiSad5);
                    HindiSad5request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    HindiSad5request.setTitle("Bharya 2" + i + ".mp3");
                    HindiSad5request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Bharya 2 /"  + "/" + "Bharya2 " + i + ".mp3");
                    Long HindiSad5reference = download.enqueue(HindiSad5request);


                }
            }
        });

        seekBar.setMax(100);


        //function of play and pause,which will work on clicking

        imagePlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if user wants to pause so after pausing it will show the play icon to play again.
                if(mediaPlayer.isPlaying()){
                    handler.removeCallbacks(updater);
                    mediaPlayer.pause();
                    imagePlayPause.setImageResource(R.drawable.playicon);
               //else user wants to play so after playing  it will show the pause icon to pause again and will update the seekbar according to the progress of song.
                }else {
                    mediaPlayer.start();
                    imagePlayPause.setImageResource(R.drawable.pause);
                    updateSeekBar();
                }
            }
        });


        //for displaying the songs list on the screen
        displaySong();
    }

    //displaySong method
    public void displaySong(){
        //HindiSadSongsList variable is used for putting url of all hindiFunSongs songs which is from online streaming.
        final List<String> HindiSadSongsList= new ArrayList<>();
        HindiSadSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Filhaal2%20Mohabbat%20%20%20Akshay%20Kumar%20Ft%20Nupur%20Sanon%20%20%20Ammy%20Virk%20%20%20BPraak%20%20%20Jaani%20%20%20Arvindr%20Khaira.mp3?alt=media&token=5dcc5063-14e5-4d99-945a-9c0a2cddd07a");
        HindiSadSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Chhor%20Denge%20Song%20-%20Nora%20Fatehi%20ft%20%20Ehan%20bhatt%20%20%20Parampara%20T%20%20%20Sachet-Tandon%20B%20%20%20Chhor%20Denge%20New%20Song.mp3?alt=media&token=f2f97005-7679-49fd-b3b5-c4b7fad9c846");
        HindiSadSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Mann%20Bharryaa%202%200%20%20From%20%20Shershaah%20%20.mp3?alt=media&token=c6ac2de3-9f73-4dcb-bbf8-3a4e55efaeb4");
        HindiSadSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Lyrical%20%20Tum%20Hi%20Aana%20%20%20Marjaavaan%20%20%20Riteish%20D%20%20Sidharth%20M%20%20Tara%20S%20%20Jubin%20Nautiyal%20Payal%20Dev%20Kunaal%20V.mp3?alt=media&token=25db7b63-9085-4159-9524-a552caaac18c");
        HindiSadSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Mann%20Bharryaa%202%200%20%20From%20%20Shershaah%20%20.mp3?alt=media&token=c6ac2de3-9f73-4dcb-bbf8-3a4e55efaeb4");

//Adapter for Hindi Sad Songs
        ArrayAdapter arrayAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, HindiSadSongsList){

            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                //Setting the view of text for Hindi Sad Songs List which will be appeared on the screen
                TextView txtSong=(TextView) super.getView(position, convertView, parent);
                txtSong.setTag( HindiSadSongsList.get(position));
                txtSong.setTextColor(Color.parseColor("#FFFFFFFF"));
                txtSong.setTypeface(txtSong.getTypeface(), Typeface.BOLD);
                txtSong.setText( HindiSadSongsList.get(position).substring( HindiSadSongsList.get(position).lastIndexOf("/")+1));
                txtSong.setTextSize(TypedValue.COMPLEX_UNIT_DIP,22);
                return txtSong;

            }
        };

//all the list of HindiSadSongs will be appeared in the listView
        ListView listView=(ListView)findViewById(R.id.ListView);

        //method for clicking on any one of list item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                //will show the name of current song playing
                currentUrlFromStream=view.getTag().toString();
                CurrentSongName.setText(currentUrlFromStream.substring(currentUrlFromStream.lastIndexOf("/")+1));

                try{
                    if(mediaPlayer!=null){
                        mediaPlayer.stop();
                    }
                    pauseAtLength=0;
                    mediaPlayer=new MediaPlayer();
                    mediaPlayer.setDataSource(currentUrlFromStream);
                    mediaPlayer.prepareAsync();

                    //When any one of the items song list will be clicked  it will show the current playing songs with pause icon to pause it
                    // also it will show the current and total duration of played song.
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            mediaPlayer.start();
                            imagePlayPause.setImageResource(R.drawable.pause);
                            TotalDuration.setText(milliSecondsToTimer(mediaPlayer.getDuration()));
                            updateSeekBar();
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();

                }
            }
        });

        listView.setAdapter(arrayAdapter);




    }

    //function or method for updating the current time of played song
    private Runnable updater = new Runnable() {
        @Override
        public void run() {
            updateSeekBar();
            long currentDuration = mediaPlayer.getCurrentPosition();
            CurrentTime.setText(milliSecondsToTimer(currentDuration));

        }
    };
    //function for updating the seekbar of current played song
    private void updateSeekBar(){
        if(mediaPlayer.isPlaying()){
            seekBar.setProgress((int) (((float) mediaPlayer.getCurrentPosition()/ mediaPlayer.getDuration()) *100));
            handler.postDelayed(updater, 1000);
        }
    }

    //method for detecting the timing of current played song in hours,minutes or seconds
    private String milliSecondsToTimer(long milliSeconds){
        String timerString="";
        String secondsString;

        int hours = (int)(milliSeconds / (1000*60*60));
        int minutes = (int)(milliSeconds % (1000*60*60)) / (1000*60);
        int seconds = (int)(milliSeconds % (1000*60*60)) % (1000*60) / (1000);

        if (hours > 0){
            timerString = hours + ":";

        }
        if(seconds < 10){
            secondsString = "0" + seconds;

        }else{
            secondsString="" + seconds;
        }

        timerString = timerString + minutes + ":" +secondsString;
        return timerString;
    }

    //after clicking on home icon from HindiSadSongsPlayActivity page,it will lead to previous home activity or user can use default back button
    public void Home(View view){
        onBackPressed();
    }

    //if user wants to go on setting from HindiSadSongsPlayActivity Page so he can click on the setting icon which is available at the bottom on the screen
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


    }

    //if user wants to go on search from HindiSadSongsPlayActivity  Page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }





}