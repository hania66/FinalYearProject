package com.example.soundiify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class
 EnglishMoodActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_englishmood);
    }

    //if user wants to go on setting from EnglishMoodActivity  Page so he can click on the setting icon which is available at the bottom on the screen//to go on settings
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


    }

    //if user wants to go on search from EnglishMoodActivity page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }

    //after clicking on the RomanticBox it will show the EnglishRomanticSongsPlay Page where user can see the list of English romantic songs and can play from the list
    public void EnglishRomanticSongs(View view){
        startActivity(new Intent(getApplicationContext(),EnglishRomanticSongsPlay.class));

    }

    //after clicking on the FunBox it will show the EnglishFunSongsPlay Page where user can see the list of English Fun songs and can play from the list

    public void FunEnglishSongs(View view){
        startActivity(new Intent(getApplicationContext(),EnglishFunSongPlay.class));

    }

    //after clicking on the sadBox it will show the EnglishSadSongsPlay Page where user  can see the list of English sad songs and can play from the list
    public void SadEnglishSongs(View view){
        startActivity(new Intent(getApplicationContext(),EnglishSadSongPlay.class));

    }

    //if user wants to logout from EnglishMoodActivity  page so he can click on the text(logout) which is available on the top right under profile icon.
    // after logging out ,it will lead to the SignInActivityPage
    public void logout(View view){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),SignInActivity.class));
        finish();

    }


}