package com.example.soundiify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class ExistingUserHome extends AppCompatActivity {
    // variables
    //*note here are some unnecessary variables used,these are important for fyp.That's why these  are hidden on the runnable screen for the time being ,so later I could easily use for fyp.
    //*Sorry for inconvenience
    private CheckBox checkboxEnglish,checkboxhindi,checkboxRomantic,checkboxSad,checkboxFun,checkboxMindfulness,checkboxFocused,checkboxRelaxation,checkBoxMeditation;
    private Button save;
    private ImageView newEnglish;
    private ImageView newHindi,iconBox,home,search,setting;
    private ImageView newMeditation;
    private TextView englishnew,welcome,choose,selectLanguage,selectMood,selectMeditation,recommendation,newReleasedSongs,Languagesbox,Moodbox,Meditationbox;;
    private TextView hindinew;
    private TextView meditationnew;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_existing_user_home);

        //Registering the variables

        checkboxEnglish=findViewById(R.id.checkboxEnglish);
        checkboxhindi=findViewById(R.id.checkboxhindi);
        checkboxRomantic=findViewById(R.id.checkboxRomantic);
        checkboxSad=findViewById(R.id.checkboxSad);
        checkboxFun=findViewById(R.id.checkboxFun);
        checkboxMindfulness=findViewById(R.id.checkboxMindfulness);
        checkboxFocused=findViewById(R.id.checkboxFocused);
        checkboxRelaxation=findViewById(R.id.checkboxRelaxation);
        checkBoxMeditation=findViewById(R.id.checkBoxMeditation);
        save=findViewById(R.id.save);
        newEnglish=findViewById(R.id.newEnglishRomantic);
        newHindi=findViewById(R.id.newHindi);
        newMeditation=findViewById(R.id.newMeditation);
        englishnew=findViewById(R.id.englishnewRomantic);
        hindinew=findViewById(R.id.hindinew);
        meditationnew=findViewById(R.id.meditationnew);
        welcome=findViewById(R.id.welcome);
        choose=findViewById(R.id.choose);
        selectLanguage=findViewById(R.id.selectLanguage);
        selectMood=findViewById(R.id.selectMood);
        selectMeditation=findViewById(R.id.selectMeditation);
        recommendation=findViewById(R.id.recommendation);
        iconBox=findViewById(R.id.iconBox);
        home=findViewById(R.id.home);
        search=findViewById(R.id.Search);
        setting=findViewById(R.id.setting);
        newReleasedSongs=findViewById(R.id.newReleasedsongs2);
        Languagesbox=findViewById(R.id.Languagesbox);
        Moodbox=findViewById(R.id.Moodbox);
        Meditationbox=findViewById(R.id.Meditationbox);


//After Signing In user will see all the new released recommendations in English ,Hindi and Meditation by setting visibility to visible.

        welcome.setVisibility(View.INVISIBLE);
        choose.setVisibility(View.INVISIBLE);
        selectLanguage.setVisibility(View.INVISIBLE);
        checkboxEnglish.setVisibility(View.INVISIBLE);
        checkboxhindi.setVisibility(View.INVISIBLE);
        checkboxRomantic.setVisibility(View.INVISIBLE);
        checkboxSad.setVisibility(View.INVISIBLE);
        checkboxFun.setVisibility(View.INVISIBLE);
        selectMood.setVisibility(View.INVISIBLE);
        selectMeditation.setVisibility(View.INVISIBLE);
        checkboxMindfulness.setVisibility(View.INVISIBLE);
        checkboxFocused.setVisibility(View.INVISIBLE);
        checkboxRelaxation.setVisibility(View.INVISIBLE);
        checkBoxMeditation.setVisibility(View.INVISIBLE);
        Languagesbox.setVisibility(View.INVISIBLE);
        Meditationbox.setVisibility(View.INVISIBLE);
        Moodbox.setVisibility(View.INVISIBLE);
        save.setVisibility(View.INVISIBLE);

//This time user can't see the choose music preference page in the start of signIn as it will be set to invisible.
        recommendation.setVisibility(View.VISIBLE);
        newReleasedSongs.setVisibility(View.VISIBLE);
        newEnglish.setVisibility(View.VISIBLE);
        englishnew.setVisibility(View.VISIBLE);
        iconBox.setVisibility(View.VISIBLE);
        home.setVisibility(View.VISIBLE);
        search.setVisibility(View.VISIBLE);
        setting.setVisibility(View.VISIBLE);
        newHindi.setVisibility(View.VISIBLE);
        hindinew.setVisibility(View.VISIBLE);
        newMeditation.setVisibility(View.VISIBLE);
        meditationnew.setVisibility(View.VISIBLE);

    }

    //if user wants to go on search from ExistingUserHome page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }


    //if user wants to go on setting from ExistingUserHome  Page so he can click on the setting icon which is available at the bottom on the screen
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


    }


    //if user wants to logout from ExistingUserHome  page so he can click on the text(logout) which is available on the top right under profile icon.
    // after logging out ,it will lead to the SignInActivityPage
    public void logout(View view){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),SignInActivity.class));
        finish();

    }
    //after clicking on the HindiBox it will show the HindiMoodActivity Page where user will see the different moods in the box of fun,sad and romantic
    public void newReleasedHindiSongs(View view){
        startActivity(new Intent(getApplicationContext(),HindiMoodActivity.class));


    }

    //after clicking on the EnglishBox it will show the EnglishMoodActivity Page where user will see the different moods in the box of fun,sad and romantic
    public void newEnglishReleasedSongs(View view){
        startActivity(new Intent(getApplicationContext(),EnglishMoodActivity.class));


    }

    //after clicking on the MeditationBox it will show the MeditationMoodActivity Page where user will see the different moods in the box of  mindfulness,focused and relaxation
    public void NewReleasedMeditation(View view){
        startActivity(new Intent(getApplicationContext(),MeditationMoodActivity.class));


    }

}