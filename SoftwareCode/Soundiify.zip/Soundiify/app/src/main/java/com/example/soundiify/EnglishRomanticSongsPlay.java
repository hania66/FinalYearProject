package com.example.soundiify;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.google.firebase.auth.FirebaseAuth;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EnglishRomanticSongsPlay extends AppCompatActivity {

    //variables
    private ListView ListView;
    private ImageView imagePlayPause,RomanticDownload;
    private TextView CurrentTime,TotalDuration,CurrentSongName;
    private SeekBar seekBar;
    private MediaPlayer mediaPlayer;
    private String currentUrlFromStream;
    private int pauseAtLength;
    private Handler handler = new Handler();
    private DownloadManager download;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english_romantic_songs_play);

        // registering variables
        imagePlayPause=findViewById(R.id.imagePlayPause);
        RomanticDownload=findViewById(R.id.EnglishRomanticDownload);
        CurrentTime=findViewById(R.id.CurrentTime);
        TotalDuration=findViewById(R.id.TotalDuration);
        seekBar=findViewById(R.id.seekBar);
        CurrentSongName=findViewById(R.id.CurrentSongName);
        ListView =findViewById(R.id.ListView);
        mediaPlayer = new MediaPlayer();


        //It will download all the English Romantic Songs Playlist when user will click on the downloading icon which is available on the top of the play list
        RomanticDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // For Loop for downloading all playlist
                for (int i = 0; i < 1; i++){
                    download = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri uriEnglishRomantic1 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Shane%20Filan%20-%20Beautiful%20In%20White%20%20%20.mp3?alt=media&token=e0e9f451-d681-4141-87df-f08ee84ad4f2");
                    DownloadManager.Request EnglishRomantic1request = new DownloadManager.Request(uriEnglishRomantic1);
                    EnglishRomantic1request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishRomantic1request.setTitle( "Shane Filan-Beautiful In White" + i + ".mp3");
                    EnglishRomantic1request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Shane Filan-Beautiful In White/"  + "/" + "Shane Filan-Beautiful In White" + i + ".mp3");
                    Long EnglishRomantic1reference = download.enqueue(EnglishRomantic1request);



                    //
                    Uri uriEnglishRomantic2 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/DJ%20Snake%20ft%20%20Justin%20Bieber%20-%20Let%20Me%20Love%20You%20%20Lyric%20Video%20.mp3?alt=media&token=61f7b3cf-1e21-41db-a855-a4ace6f4332f");
                    DownloadManager.Request EnglishRomantic2request = new DownloadManager.Request(uriEnglishRomantic2);
                    EnglishRomantic2request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishRomantic2request.setTitle( "DJ Snake" + i + ".mp3");
                    EnglishRomantic2request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Dj Snake/"  + "/" + "DJ Snake" + i + ".mp3");
                    Long EnglishRomantic2reference = download.enqueue(EnglishRomantic2request);


                    Uri uriEnglishRomantic3 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Ellie%20Goulding%20-%20Love%20Me%20Like%20You%20Do%20%20%20.mp3?alt=media&token=5b765678-07c2-4298-8bc9-c1e481346fad");
                    DownloadManager.Request EnglishRomantic3request = new DownloadManager.Request(uriEnglishRomantic3);
                    EnglishRomantic3request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishRomantic3request.setTitle( " Love Me Like You Do" + i + ".mp3");
                    EnglishRomantic3request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Love Me Like You Do/"  + "/" + "Love Me Like You Do" + i + ".mp3");
                    Long EnglishRomantic3reference = download.enqueue(EnglishRomantic3request);


                    Uri uriEnglishRomantic4 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Avril%20Lavigne%20-%20Bite%20Me%20%20%20.mp3?alt=media&token=99fa3498-b7fa-4f3c-b0ba-7e0a77ca12d8");
                    DownloadManager.Request EnglishRomantic4request = new DownloadManager.Request(uriEnglishRomantic4);
                    EnglishRomantic4request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishRomantic4request.setTitle( "Avril Lavigne - Bite Me" + i + ".mp3");
                    EnglishRomantic4request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Avril Lavigne - Bite Me/"  + "/" + "Avril Lavigne - Bite Me" + i + ".mp3");
                    Long EnglishRomantic4reference = download.enqueue(EnglishRomantic4request);


                    Uri uriEnglishRomantic5 = Uri.parse("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Ed%20Sheeran%20-%20Shape%20of%20You%20%20Lyrics%20.mp3?alt=media&token=133a9173-646f-4539-9eaf-d5b742e34864");
                    DownloadManager.Request EnglishRomantic5request = new DownloadManager.Request(uriEnglishRomantic5);
                    EnglishRomantic5request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    EnglishRomantic5request.setTitle( "Ed Sheeran - Shape of You " + i + ".mp3");
                    EnglishRomantic5request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/Ed Sheeran - Shape of You /"  + "/" + "Ed Sheeran - Shape of You " + i + ".mp3");
                    Long EnglishRomantic5reference = download.enqueue(EnglishRomantic5request);




                }
            }
        });

        seekBar.setMax(100);


        //function of play and pause,which will work on clicking
        imagePlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if user wants to pause ,so after pausing it will show the play icon to play again.
                if(mediaPlayer.isPlaying()){
                    handler.removeCallbacks(updater);
                    mediaPlayer.pause();
                    imagePlayPause.setImageResource(R.drawable.playicon);
                    //else user wants to play so after playing it will show the pause icon to pause again and will update the seekbar according to the progress of song.
                }else {
                    mediaPlayer.start();
                    imagePlayPause.setImageResource(R.drawable.pause);
                    updateSeekBar();
                }
            }
        });


        //for displaying the songs list on the screen
        displaySong();
    }

    //displaySong method
    public void displaySong(){
        //EnglishRomanticSongsList variable is used for putting url of all EnglishRomanticSongs songs which is from online streaming.
        final List<String> EnglishRomanticSongsList= new ArrayList<>();
        EnglishRomanticSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Shane%20Filan%20-%20Beautiful%20In%20White%20%20%20.mp3?alt=media&token=e0e9f451-d681-4141-87df-f08ee84ad4f2");
        EnglishRomanticSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/DJ%20Snake%20ft%20%20Justin%20Bieber%20-%20Let%20Me%20Love%20You%20%20Lyric%20Video%20.mp3?alt=media&token=61f7b3cf-1e21-41db-a855-a4ace6f4332f");
        EnglishRomanticSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Ellie%20Goulding%20-%20Love%20Me%20Like%20You%20Do%20%20%20.mp3?alt=media&token=5b765678-07c2-4298-8bc9-c1e481346fad");
        EnglishRomanticSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Avril%20Lavigne%20-%20Bite%20Me%20%20%20.mp3?alt=media&token=99fa3498-b7fa-4f3c-b0ba-7e0a77ca12d8");
        EnglishRomanticSongsList.add("https://firebasestorage.googleapis.com/v0/b/soundiify.appspot.com/o/Ed%20Sheeran%20-%20Shape%20of%20You%20%20Lyrics%20.mp3?alt=media&token=133a9173-646f-4539-9eaf-d5b742e34864");

        //Adapter for English Romantic Songs
        ArrayAdapter arrayAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,EnglishRomanticSongsList){

            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                //Setting the view of text for English Romantic Songs List which will be appeared on the screen
                TextView txtSong=(TextView) super.getView(position, convertView, parent);
                txtSong.setTag(EnglishRomanticSongsList.get(position));
                txtSong.setTextColor(Color.parseColor("#FFFFFFFF"));
                txtSong.setTypeface(txtSong.getTypeface(), Typeface.BOLD);
                txtSong.setText(EnglishRomanticSongsList.get(position).substring(EnglishRomanticSongsList.get(position).lastIndexOf("/")+1));
                txtSong.setTextSize(TypedValue.COMPLEX_UNIT_DIP,22);
                return txtSong;

            }
        };

        //all the list of EnglishRomanticSongs will be appeared in the listView
        ListView listView=(ListView)findViewById(R.id.ListView);

        //method for clicking on any one of list item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                //will show the name of current song playing
                currentUrlFromStream=view.getTag().toString();
                CurrentSongName.setText(currentUrlFromStream.substring(currentUrlFromStream.lastIndexOf("/")+1));

                try{
                    if(mediaPlayer!=null){
                        mediaPlayer.stop();
                    }
                    pauseAtLength=0;
                    mediaPlayer=new MediaPlayer();
                    mediaPlayer.setDataSource(currentUrlFromStream);
                    mediaPlayer.prepareAsync();

                    //When any one of the items song list will be clicked  it will show the current playing songs with pause icon to pause it
                    // also it will show the current and total duration of played song
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            mediaPlayer.start();
                            imagePlayPause.setImageResource(R.drawable.pause);
                            TotalDuration.setText(milliSecondsToTimer(mediaPlayer.getDuration()));
                            updateSeekBar();
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();

                }
            }
        });

        listView.setAdapter(arrayAdapter);




    }


    //function or method for updating the current time of played song
    private Runnable updater = new Runnable() {
        @Override
        public void run() {
            updateSeekBar();
            long currentDuration = mediaPlayer.getCurrentPosition();
            CurrentTime.setText(milliSecondsToTimer(currentDuration));

        }
    };

    //function for updating the seekbar of current played song
    private void updateSeekBar(){
        if(mediaPlayer.isPlaying()){
            seekBar.setProgress((int) (((float) mediaPlayer.getCurrentPosition()/ mediaPlayer.getDuration()) *100));
            handler.postDelayed(updater, 1000);
        }
    }

    //method for detecting the timing of current played song in hours,minutes or seconds
    private String milliSecondsToTimer(long milliSeconds){
        String timerString="";
        String secondsString;

        int hours = (int)(milliSeconds / (1000*60*60));
        int minutes = (int)(milliSeconds % (1000*60*60)) / (1000*60);
        int seconds = (int)(milliSeconds % (1000*60*60)) % (1000*60) / (1000);

        if (hours > 0){
            timerString = hours + ":";

        }
        if(seconds < 10){
            secondsString = "0" + seconds;

        }else{
            secondsString="" + seconds;
        }

        timerString = timerString + minutes + ":" +secondsString;
        return timerString;
    }

    //after clicking on home icon from EnglishRomanticSongsPlayActivity page,it will lead to previous home activity or user can use default back button
    public void Home(View view){
        onBackPressed();
    }

    //if user wants to go on settings from EnglishRomanticSongsPlayActivity  Page so he can click on the search icon which is available at the bottom on the screen
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


    }

    //if user wants to go on search from EnglishRomanticSongsPlayActivity  Page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }


}