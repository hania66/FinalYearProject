package com.example.soundiify;

public class User {

    private String Preference;

    public User(){}

    public String getPreference() {
        return Preference;
    }

    public void setPreference(String preference) {
        Preference = preference;
    }
}
