package com.example.soundiify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;

public class MeditationMoodActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meditation_mood);
    }


    //if user wants to go on setting from MeditationMoodActivity  Page so he can click on the setting icon which is available at the bottom on the screen//to go on settings
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


    }

    //if user wants to go on search from MeditationMoodActivity page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }

    //after clicking on the FocusedBox it will show the MeditationFocusedPlayActivity Page where user  can see the list of Meditation Focused Music and can play from the list
    public void focusedMeditation(View view){
        startActivity(new Intent(getApplicationContext(),MeditationFocusedPlayActivity.class));


    }

    //after clicking on the MindfulnesssBox it will show the MindfulnessPlayActivity Page where user can see the list of Meditation Mindfulnesss Music and can play from the list
    public void mindfulnessMeditation(View view){
        startActivity(new Intent(getApplicationContext(), MindfulnessPlayActivity.class));


    }


    //after clicking on the RelaxationBox it will show the MeditationRelaxationPlayActivity Page where user  can see the list of Meditation Relaxation Music and can play from the list

    public void relaxationMeditation(View view){
        startActivity(new Intent(getApplicationContext(),MeditationRelaxationActivity.class));


    }



    //if user wants to logout from MeditationMoodActivity  page so he can click on the text(logout) which is available on the top right under profile icon.
    // after logging out ,it will lead to the SignInActivityPage
    public void logout(View view){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),SignInActivity.class));
        finish();

    }
}