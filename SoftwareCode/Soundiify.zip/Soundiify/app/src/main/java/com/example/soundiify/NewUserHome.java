package com.example.soundiify;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class NewUserHome extends AppCompatActivity {
// variables
    //*note here are some unnecessary variables used,these are important for fyp.That's why these  are hidden on the runnable screen for the time being ,so later I could easily use for fyp.
    //*Sorry for inconvenience
    private CheckBox checkboxEnglish,checkboxhindi,checkboxRomantic,checkboxSad,checkboxFun,checkboxMindfulness,checkboxFocused,checkboxRelaxation,checkBoxMeditation;
    private Button save;
    private ImageView newEnglish;
    private ImageView newHindi,iconBox,home,search,setting;
    private ImageView newMeditation;
    private TextView englishnew,welcome,choose,selectLanguage,selectMood,selectMeditation,recommendation,newReleasedSongs,Languagesbox,Moodbox,Meditationbox;;
    private TextView hindinew;
    private TextView meditationnew;
    FirebaseDatabase database;
    DatabaseReference reference;
    User  user; //user class
    int i =0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_new_user_home);


     reference = database.getInstance().getReference().child("MusicPreferenceForm");



      //Registering the variables
        user = new User(); //this class is registered for getting and setting the value of  music preference form
        checkboxEnglish=findViewById(R.id.checkboxEnglish);
        checkboxhindi=findViewById(R.id.checkboxhindi);
        checkboxRomantic=findViewById(R.id.checkboxRomantic);
        checkboxSad=findViewById(R.id.checkboxSad);
        checkboxFun=findViewById(R.id.checkboxFun);
        checkboxMindfulness=findViewById(R.id.checkboxMindfulness);
        checkboxFocused=findViewById(R.id.checkboxFocused);
        checkboxRelaxation=findViewById(R.id.checkboxRelaxation);
        checkBoxMeditation=findViewById(R.id.checkBoxMeditation);
        save=findViewById(R.id.save);
        newEnglish=findViewById(R.id.newEnglishRomantic);
        newHindi=findViewById(R.id.newHindi);
        newMeditation=findViewById(R.id.newMeditation);
        englishnew=findViewById(R.id.englishnewRomantic);
        hindinew=findViewById(R.id.hindinew);
        meditationnew=findViewById(R.id.meditationnew);
        welcome=findViewById(R.id.welcome);
        choose=findViewById(R.id.choose);
        selectLanguage=findViewById(R.id.selectLanguage);
        selectMood=findViewById(R.id.selectMood);
        selectMeditation=findViewById(R.id.selectMeditation);
        recommendation=findViewById(R.id.recommendation);
        iconBox=findViewById(R.id.iconBox);
        home=findViewById(R.id.home);
        search=findViewById(R.id.Search);
        setting=findViewById(R.id.setting);
        newReleasedSongs=findViewById(R.id.newReleasedsongs2);
        Languagesbox=findViewById(R.id.Languagesbox);
        Moodbox=findViewById(R.id.Moodbox);
        Meditationbox=findViewById(R.id.Meditationbox);

         //made strings for taking value
        String p1 ="English";
        String p2 ="Hindi";
        String p3 ="Meditation";

        //used for storing and updating the values on Firebase
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    i = (int)snapshot.getChildrenCount();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });








        //form of checkboxes with if else condition
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //lets suppose if user will check the the checkbox of English which is on the screen so it will hide Choose Music Preference Form with all checklist options by setting visibility to invisible
                // and will recommend the only new released English box by setting  visibility to visible and also the icon of home,search and setting at the bottom.

                if(checkboxEnglish.isChecked()){


                    user.setPreference(p1);
                    reference.child(String.valueOf(i+1)).setValue(user);


                    recommendation.setVisibility(View.VISIBLE);
                    newReleasedSongs.setVisibility(View.VISIBLE);
                    newEnglish.setVisibility(View.VISIBLE);
                    englishnew.setVisibility(View.VISIBLE);
                    checkboxEnglish.setVisibility(View.VISIBLE);
                    iconBox.setVisibility(View.VISIBLE);
                    home.setVisibility(View.VISIBLE);
                    search.setVisibility(View.VISIBLE);
                    setting.setVisibility(View.VISIBLE);
                    welcome.setVisibility(View.INVISIBLE);
                    choose.setVisibility(View.INVISIBLE);
                    selectLanguage.setVisibility(View.INVISIBLE);
                    checkboxEnglish.setVisibility(View.INVISIBLE);
                    checkboxhindi.setVisibility(View.INVISIBLE);
                    checkboxRomantic.setVisibility(View.INVISIBLE);
                    checkboxSad.setVisibility(View.INVISIBLE);
                    checkboxFun.setVisibility(View.INVISIBLE);
                    selectMood.setVisibility(View.INVISIBLE);
                    selectMeditation.setVisibility(View.INVISIBLE);
                    checkboxMindfulness.setVisibility(View.INVISIBLE);
                    checkboxFocused.setVisibility(View.INVISIBLE);
                    checkboxRelaxation.setVisibility(View.INVISIBLE);
                    checkBoxMeditation.setVisibility(View.INVISIBLE);
                    Languagesbox.setVisibility(View.INVISIBLE);
                    Meditationbox.setVisibility(View.INVISIBLE);
                    Moodbox.setVisibility(View.INVISIBLE);
                    save.setVisibility(View.INVISIBLE);


               //else nothing will be happened
                }else{

                }
                //lets suppose if user will check the the checkbox of Hindi which is on the screen so it will hide Choose Music Preference Form with all checklist options by setting visibility to invisible
                // and will recommend the only new released Hindi  box by setting  visibility to visible and also the icon of home,search and setting at the bottom.

                if(checkboxhindi.isChecked()){
                    user.setPreference(p2);
                    reference.child(String.valueOf(i+1)).setValue(user);

                    recommendation.setVisibility(View.VISIBLE);
                    newReleasedSongs.setVisibility(View.VISIBLE);
                    newHindi.setVisibility(View.VISIBLE);
                    hindinew.setVisibility(View.VISIBLE);
                    checkboxhindi.setVisibility(View.VISIBLE);
                    iconBox.setVisibility(View.VISIBLE);
                    home.setVisibility(View.VISIBLE);
                    search.setVisibility(View.VISIBLE);
                    setting.setVisibility(View.VISIBLE);
                    welcome.setVisibility(View.INVISIBLE);
                    choose.setVisibility(View.INVISIBLE);
                    selectLanguage.setVisibility(View.INVISIBLE);
                    checkboxEnglish.setVisibility(View.INVISIBLE);
                    checkboxhindi.setVisibility(View.INVISIBLE);
                    checkboxRomantic.setVisibility(View.INVISIBLE);
                    checkboxSad.setVisibility(View.INVISIBLE);
                    checkboxFun.setVisibility(View.INVISIBLE);
                    selectMood.setVisibility(View.INVISIBLE);
                    checkBoxMeditation.setVisibility(View.INVISIBLE);
                    selectMeditation.setVisibility(View.INVISIBLE);
                    checkboxMindfulness.setVisibility(View.INVISIBLE);
                    checkboxFocused.setVisibility(View.INVISIBLE);
                    checkboxRelaxation.setVisibility(View.INVISIBLE);
                    Languagesbox.setVisibility(View.INVISIBLE);
                    Meditationbox.setVisibility(View.INVISIBLE);
                    Moodbox.setVisibility(View.INVISIBLE);
                    save.setVisibility(View.INVISIBLE);
               //else nothing will be happened
                }else{

                }

                //lets suppose if user will check the the checkbox of Meditation which is on the screen so it will hide Choose Music Preference Form with all checklist options by setting visibility to invisible
                // and will recommend the only new released Meditation box by setting  visibility to visible and also the icon of home,search and setting at the bottom.

                if(checkBoxMeditation.isChecked()){

                    user.setPreference(p3);
                    reference.child(String.valueOf(i+1)).setValue(user);

                    recommendation.setVisibility(View.VISIBLE);
                    newReleasedSongs.setVisibility(View.VISIBLE);
                    newMeditation.setVisibility(View.VISIBLE);
                    meditationnew.setVisibility(View.VISIBLE);
                    checkboxhindi.setVisibility(View.VISIBLE);
                    iconBox.setVisibility(View.VISIBLE);
                    home.setVisibility(View.VISIBLE);
                    search.setVisibility(View.VISIBLE);
                    setting.setVisibility(View.VISIBLE);
                    welcome.setVisibility(View.INVISIBLE);
                    choose.setVisibility(View.INVISIBLE);
                    selectLanguage.setVisibility(View.INVISIBLE);
                    checkboxEnglish.setVisibility(View.INVISIBLE);
                    checkboxhindi.setVisibility(View.INVISIBLE);
                    checkboxRomantic.setVisibility(View.INVISIBLE);
                    checkboxSad.setVisibility(View.INVISIBLE);
                    checkboxFun.setVisibility(View.INVISIBLE);
                    selectMood.setVisibility(View.INVISIBLE);
                    selectMeditation.setVisibility(View.INVISIBLE);
                    checkboxMindfulness.setVisibility(View.INVISIBLE);
                    checkboxFocused.setVisibility(View.INVISIBLE);
                    checkboxRelaxation.setVisibility(View.INVISIBLE);
                    checkBoxMeditation.setVisibility(View.INVISIBLE);
                    Languagesbox.setVisibility(View.INVISIBLE);
                    Meditationbox.setVisibility(View.INVISIBLE);
                    Moodbox.setVisibility(View.INVISIBLE);
                    save.setVisibility(View.INVISIBLE);


                }




            }
        });

    }



    //if user wants to go on setting from NewUSerHome page so he can click on the setting icon which is available at the bottom on the screen
    public void Settings(View view){
        startActivity(new Intent(getApplicationContext(),Settings.class));


    }
    //if user wants to go on search from NewUSerHome page so he can click on the search icon which is available at the bottom on the screen
    public void Search(View view){
        startActivity(new Intent(getApplicationContext(),SearchActivity.class));


    }

    //if user wants to logout from NewUSerHome page so he can click on the text(logout) which is available on the top right under profile icon.
    //after logging out ,it will lead to the SignInActivityPage
    public void logout(View view){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),SignInActivity.class));
        finish();

    }

    //after clicking on the EnglishBox it will show the EnglishMoodActivity Page where user will see the different moods in the box of fun,sad and romantic
    public void newEnglishReleasedSongs(View view){
        startActivity(new Intent(getApplicationContext(),EnglishMoodActivity.class));


    }



    //after clicking on the HindiBox it will show the HindiMoodActivity Page where user will see the different moods in the box of fun,sad and romantic
    public void newReleasedHindiSongs(View view){
        startActivity(new Intent(getApplicationContext(),HindiMoodActivity.class));


    }

    //after clicking on the MeditationBox it will show the HindiMoodActivity Page where user will see the different moods in the box of  mindfulness,focused and relaxation
    public void NewReleasedMeditation(View view){
        startActivity(new Intent(getApplicationContext(),MeditationMoodActivity.class));


    }



}